# Enter your API key

weather_key = "3a9fa2731241e7ab03bbf05564b12ba4"


postg = {
    "host": "localhost",
    "user": "postgres",
    "passwd": "postgres",
    "db": "DAJobSearch"}